//src\components\Setlists\SetlistSongCard.tsx
import { useSortable } from '@dnd-kit/sortable';
import { CSS } from '@dnd-kit/utilities';
import { useState, useRef, useEffect } from 'react';
import { cn } from '@/lib/utils';
import { MoreVertical, CornerRightDown, Trash2 } from 'lucide-react';
import type { BandSong } from '@/lib/types/song';
import { DurationtoMinSec } from '@/lib/services/bandflowhelpers/SetListHelpers';

interface SetlistSongCardProps {
  id: string;          // Instance ID
  songId: string;      // Reference to original song
  song: BandSong;
  index: number;
  setId: string;
  onRemove?: () => void;
  onToggleSegue?: () => void;
  hasSegue?: boolean;
}

export function SetlistSongCard({ 
  id,  // Using instance ID for DnD
  songId,
  song, 
  index, 
  setId,
  onRemove,
  onToggleSegue,
  hasSegue = false
}: SetlistSongCardProps) {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);

  const {
    attributes,
    listeners,
    setNodeRef,
    transform,
    transition,
    isDragging
  } = useSortable({
    id,
    data: {
      type: 'setlist-song',
      songId,  // Pass original songId in data
      song,
      index,
      setId
    }
  });

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(event.target as Node)) {
        setIsMenuOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
    opacity: isDragging ? 0.5 : 1,
    touchAction: 'none'
  };

  const isNotPlaybook = song.status !== 'PLAYBOOK';

  return (
    <div
      ref={setNodeRef}
      style={style}
      {...attributes}
      {...listeners}
      className={cn(
        "flex items-center h-8 px-2 rounded-lg group",
        "touch-none select-none cursor-grab active:cursor-grabbing",
        isDragging ? "bg-orange-500/20" : 
          isNotPlaybook ? "bg-orange-500/10 hover:bg-orange-500/20 border border-orange-500/50" : 
          "bg-gray-700/50 hover:bg-gray-700"
      )}
    >
      <span className="w-6 text-xs text-gray-400">{index + 1}</span>
      <div className="flex-1 min-w-0">
        <div className={cn(
          "font-medium text-sm truncate flex items-center gap-1",
          isNotPlaybook ? "text-orange-400" : "text-white"
        )}>
          {song.title}
          {isNotPlaybook && (
            <span className="text-xs">⚠️</span>
          )}
        </div>
      </div>
      {song.metadata?.duration && (
        <div className="text-xs text-gray-400 ml-2">
          {DurationtoMinSec(parseInt(song.metadata.duration))}
        </div>
      )}

      {hasSegue && (
        <div className="mx-2 text-green-500">
          <CornerRightDown className="w-4 h-4" />
        </div>
      )}

      <div className="relative" ref={menuRef}>
        <button
          onClick={(e) => {
            e.stopPropagation();
            setIsMenuOpen(!isMenuOpen);
          }}
          className={cn(
            "p-1 rounded-full transition-colors",
            isMenuOpen ? "bg-gray-600 text-white" : "text-gray-400 hover:text-white"
          )}
        >
          <MoreVertical className="w-4 h-4" />
        </button>

        {isMenuOpen && (
          <div className="absolute right-0 top-8 bg-gray-800 rounded-lg shadow-lg border border-gray-700 w-40 py-1 z-50">
            <button
              onClick={(e) => {
                e.stopPropagation();
                onToggleSegue?.();
                setIsMenuOpen(false);
              }}
              className="w-full px-3 py-2 text-sm text-left text-gray-300 hover:bg-gray-700 flex items-center gap-2"
            >
              <CornerRightDown className="w-4 h-4" />
              {hasSegue ? "Remove Segue" : "Add Segue"}
            </button>
            <button
              onClick={(e) => {
                e.stopPropagation();
                onRemove?.();
                setIsMenuOpen(false);
              }}
              className="w-full px-3 py-2 text-sm text-left text-red-400 hover:bg-gray-700 flex items-center gap-2"
            >
              <Trash2 className="w-4 h-4" />
              Remove
            </button>
          </div>
        )}
      </div>
    </div>
  );
}