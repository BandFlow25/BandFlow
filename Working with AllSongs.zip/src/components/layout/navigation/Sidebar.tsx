// src/components/layout/navigation/Sidebar.tsx

//TODO: Add Month Calendar widget
import { useState } from 'react';
import { useAuth } from '@/contexts/auth/AuthProvider';
import { useBand } from '@/contexts/band/BandProvider';
import { useRouter, usePathname } from 'next/navigation';
import Link from 'next/link';
import { cn } from '@/lib/utils';
import { 
  Music, Settings, LogOut, User,
  Menu, X, ChevronDown, ChevronRight, 
  BookOpen, Calendar, Image, Shuffle
} from 'lucide-react';

export default function Sidebar() {
  const [isOpen, setIsOpen] = useState(false);
  const [songMenuOpen, setSongMenuOpen] = useState(true);
  const router = useRouter();
  const pathname = usePathname();
  const { user, profile, logout } = useAuth();
  const { activeBand, setActiveBandId } = useBand();

  const handleSwitchBand = () => {
    setActiveBandId(null);
    router.push('/home');
  };

  const handleLogout = async () => {
    try {
      await logout();
      router.push('/login');
    } catch (err) {
      console.error('Logout failed:', err);
    }
  };

  if (!activeBand) return null;

  const songMenuItems = [
    {
      name: 'All Songs',
      href: `/bands/${activeBand.id}/songs`,
      icon: <Music className="w-4 h-4" />
    },
    { name: 'Suggestions', href: `/bands/${activeBand.id}/suggestions` },
    { name: 'In Voting', href: `/bands/${activeBand.id}/voting` },
    { name: 'In Review', href: `/bands/${activeBand.id}/review` },
    { name: 'Practice List', href: `/bands/${activeBand.id}/practice` },
  ];

  return (
    <>
      <button 
        onClick={() => setIsOpen(!isOpen)} 
        className="fixed top-4 left-4 z-50 lg:hidden text-white"
      >
        {isOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
      </button>

      {isOpen && (
        <div className="fixed inset-0 bg-black/50 z-40 lg:hidden" onClick={() => setIsOpen(false)} />
      )}

      <aside className={cn(
        "fixed top-0 left-0 h-full w-64 bg-gray-900 text-white z-40 transform transition-transform duration-200 ease-in-out border-r border-gray-800 flex flex-col",
        {
          "translate-x-0": isOpen,
          "-translate-x-full": !isOpen,
          "lg:translate-x-0": true,
          "lg:static": true,
        }
      )}>
        <div className="py-2 px-12 border-b border-gray-800">
          <h1 className="text-xl font-bold text-white">Band Flow 25</h1>
        </div>

        <div className="p-4 border-b border-gray-800">
          <div className="flex items-center justify-between gap-2">
            <h2 className="text-lg font-semibold text-white truncate flex-1">
              {activeBand.name}
            </h2>
            <Link 
              href={`/bands/${activeBand.id}/settings`}
              className="text-blue-500 hover:text-blue-400"
              title="Band Settings"
            >
              <Settings className="w-5 h-5" />
            </Link>
            <button
              onClick={handleSwitchBand}
              className="text-orange-500 hover:text-orange-400"
              title="Select Band"
            >
              <Shuffle className="w-5 h-5" />
            </button>
          </div>
        </div>

        <nav className="flex-1 p-4 overflow-y-auto">
          <Link
            href={`/bands/${activeBand.id}`}
            className={cn(
              "flex items-center px-2 py-2 rounded-lg mb-4",
              pathname === `/bands/${activeBand.id}`
                ? "bg-orange-500 text-white"
                : "text-gray-300 hover:text-white hover:bg-gray-800"
            )}
          >
            <BookOpen className="w-5 h-5 mr-2" />
            Play Book
          </Link>

          <div className="space-y-4">
            <div>
              <button
                onClick={() => setSongMenuOpen(!songMenuOpen)}
                className="w-full flex items-center justify-between px-2 py-2 text-gray-300 hover:text-white"
              >
                <div className="flex items-center">
                  <Music className="w-5 h-5 mr-2" />
                  <span>Songs</span>
                </div>
                {songMenuOpen ? <ChevronDown className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
              </button>
              {songMenuOpen && (
                <div className="ml-4 space-y-1 mt-2">
                  {songMenuItems.map((item) => (
                    <Link
                      key={item.href}
                      href={item.href}
                      className={cn(
                        "block px-2 py-1.5 rounded-lg text-sm",
                        pathname === item.href
                          ? "bg-orange-500 text-white"
                          : "text-gray-400 hover:text-white hover:bg-gray-800"
                      )}
                    >
                      {item.name}
                    </Link>
                  ))}
                </div>
              )}
            </div>

            <Link
              href={`/bands/${activeBand.id}/events`}
              className={cn(
                "flex items-center px-2 py-2 rounded-lg",
                pathname === `/bands/${activeBand.id}/events`
                  ? "bg-orange-500 text-white"
                  : "text-gray-300 hover:text-white hover:bg-gray-800"
              )}
            >
              <Calendar className="w-5 h-5 mr-2" />
              Events
            </Link>

            <Link
              href={`/bands/${activeBand.id}/media`}
              className={cn(
                "flex items-center px-2 py-2 rounded-lg",
                pathname === `/bands/${activeBand.id}/media`
                  ? "bg-orange-500 text-white"
                  : "text-gray-300 hover:text-white hover:bg-gray-800"
              )}
            >
              <Image className="w-5 h-5 mr-2" />
              Media
            </Link>
          </div>
        </nav>

        <div className="mt-auto p-4 border-t border-gray-800 bg-gray-800/50">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center flex-1">
              <div className="w-10 h-10 rounded-full bg-orange-500/10 flex items-center justify-center mr-3">
                <User className="w-6 h-6 text-orange-500" />
              </div>
              <span className="text-sm font-medium text-white truncate">
                {profile?.displayName || user?.email}
              </span>
            </div>
            <Link href="/profile-setup" className="text-blue-500 hover:text-blue-400 ml-2">
              <Settings className="w-5 h-5" />
            </Link>
          </div>
          <button
            onClick={handleLogout}
            className="w-full flex items-center text-orange-500 hover:text-orange-400 px-4 py-2 rounded-lg hover:bg-gray-700/50"
          >
            <LogOut className="w-5 h-5 mr-3" />
            Logout
          </button>
        </div>
      </aside>
    </>
  );
}