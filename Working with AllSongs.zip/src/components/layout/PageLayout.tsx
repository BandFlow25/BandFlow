// src/components/layout/PageLayout.tsx
import Sidebar from './navigation/Sidebar';
import AddSongButton from '@/components/ui/buttons/AddSongButton';

type PageLayoutProps = {
  children?: React.ReactNode;
  title: string;
}

export default function PageLayout({ children, title }: PageLayoutProps) {
  return (
    <div className="flex min-h-screen bg-gray-900">
      <Sidebar />
      <main className="flex-1 w-0 min-w-0">
        <div className="p-8 max-w-7xl mx-auto">
          <h1 className="text-2xl font-bold text-white mb-6">
            {title}
          </h1>
          {children}
        </div>
        <>
          <AddSongButton />
          {/* Rest of layout */}
        </>
      </main>
    </div>
  );
}