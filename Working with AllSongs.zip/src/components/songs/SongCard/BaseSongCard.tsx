// components/songs/SongCard/BaseSongCard.tsx
import { Play, Music, MoreHorizontal } from 'lucide-react';
import { cn } from '@/lib/utils';
import type { BandSong } from '@/lib/types/song';

interface BaseSongCardProps {
  song: BandSong;
  onClick?: () => void;
  className?: string;
  showMetadata?: boolean;
  children?: React.ReactNode;
}

export function BaseSongCard({ 
  song, 
  onClick, 
  className,
  showMetadata = false,
  children 
}: BaseSongCardProps) {
  return (
    <div
      className={cn(
        "group relative flex items-center gap-4 p-3 rounded-md",
        "bg-gray-800/40 hover:bg-gray-800/60",
        "transition-all duration-200 cursor-pointer",
        className
      )}
      onClick={onClick}
    >
      <div className="relative min-w-[48px] h-[48px]">
        {song.thumbnail ? (
          // Using regular img tag for now
          <img
            src={song.thumbnail}
            alt={song.title}
            className="w-12 h-12 rounded-md object-cover"
          />
        ) : (
          <div className="w-12 h-12 rounded-md bg-gray-700/50 flex items-center justify-center">
            <Music className="w-6 h-6 text-gray-400" />
          </div>
        )}
        <button
          className="absolute inset-0 flex items-center justify-center bg-black/40 rounded-md opacity-0 group-hover:opacity-100 transition-opacity"
          onClick={(e) => {
            e.stopPropagation();
            // TODO: Implement play functionality
            console.log('Play clicked:', song.title);
          }}
        >
          <Play className="w-6 h-6 text-white" fill="white" />
        </button>
      </div>

      <div className="flex-1 min-w-0">
        <h3 className="font-medium text-white truncate">{song.title}</h3>
        <p className="text-sm text-gray-400 truncate">{song.artist}</p>
        {showMetadata && song.metadata && (
          <div className="flex items-center gap-3 mt-1 text-xs text-gray-500">
            {song.metadata.bpm && (
              <span>{song.metadata.bpm} BPM</span>
            )}
            {song.metadata.key && (
              <span>{song.metadata.key}</span>
            )}
            {song.metadata.duration && (
              <span>{song.metadata.duration}</span>
            )}
          </div>
        )}
      </div>

      <div className="opacity-0 group-hover:opacity-100 transition-opacity">
        {children || (
          <button
            onClick={(e) => {
              e.stopPropagation();
              // TODO: Implement more actions
              console.log('More actions:', song.title);
            }}
            className="p-2 hover:bg-gray-700 rounded-full"
          >
            <MoreHorizontal className="w-5 h-5 text-gray-400" />
          </button>
        )}
      </div>
    </div>
  );
}