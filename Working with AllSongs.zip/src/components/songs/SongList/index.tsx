// components/songs/SongList/index.tsx
import { useState, useMemo } from 'react';
import { useSongs } from '@/contexts/songs/SongProvider';
import { SONG_LIST_TYPES, SONG_LIST_LABELS } from '@/lib/constants';
import { SongListHeader } from './SongListHeader';
import { SongListContent } from './SongListContent';
import type { BandSong } from '@/lib/types/song';

interface SongListProps {
  type: (typeof SONG_LIST_TYPES)[keyof typeof SONG_LIST_TYPES];
  showCount?: boolean;
}

export function SongList({ type, showCount = true }: SongListProps) {
  const { songs, isLoading, error, searchQuery, setSearchQuery } = useSongs();
  
  const filteredSongs = useMemo(() => {
    return songs.filter(song => {
      const search = searchQuery.toLowerCase();
      return (
        song.title.toLowerCase().includes(search) ||
        song.artist.toLowerCase().includes(search)
      );
    });
  }, [songs, searchQuery]);

  return (
    <div className="flex flex-col h-full min-h-0 bg-gray-900 pl-4 pr-4 pt-4">
      {/* Filter bar at the top */}
      <div className="flex items-center gap-2 mb-4">
        <input
          type="text"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder="Search songs..."
          className="flex-1 p-2 rounded bg-gray-800 text-white placeholder-gray-400 focus:outline-none focus:ring focus:ring-orange-500"
        />
        <span className="text-sm text-gray-500">
          {showCount ? `${filteredSongs.length} songs` : ""}
        </span>
      </div>
  
      {/* Song list content */}
      <div className="flex-1 overflow-y-auto min-h-0">
        <SongListContent
          songs={filteredSongs}
          isLoading={isLoading}
          error={error}
          onSongSelect={(song) => {
            // TODO: Implement song selection handling
            console.log("Song selected:", song);
          }}
        />
      </div>
    </div>
  );
}