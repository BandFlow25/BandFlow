// components/songs/AddSongModal.tsx
//TODO: Check in Base Songs for match before calling Spotify?
//Get metadata BPM, Duration & KEY
// Prevent dupes

import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { searchSpotifyTracks, type SpotifyTrack } from '@/lib/services/spotify';
import { addBaseSong, addBandSong } from '@/lib/services/firebase/songs';
import { useBand } from '@/contexts/band/BandProvider';
import type { SongStatus } from '@/lib/types/types';

interface AddSongModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

function useDebounce<T>(value: T, delay: number): T {
  const [debouncedValue, setDebouncedValue] = useState<T>(value);
  useEffect(() => {
    const handler = setTimeout(() => setDebouncedValue(value), delay);
    return () => clearTimeout(handler);
  }, [value, delay]);
  return debouncedValue;
}

export default function AddSongModal({ open, onOpenChange }: AddSongModalProps) {
  const { currentBandId } = useBand();
  const [query, setQuery] = useState("");
  const [suggestions, setSuggestions] = useState<SpotifyTrack[]>([]);
  const [selectedTrack, setSelectedTrack] = useState<SpotifyTrack | null>(null);
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const debouncedQuery = useDebounce(query, 300);

  useEffect(() => {
    async function searchTracks() {
      if (!debouncedQuery.trim()) {
        setSuggestions([]);
        return;
      }
      setIsLoading(true);
      try {
        const results = await searchSpotifyTracks(debouncedQuery);
        setSuggestions(results);
      } catch (err) {
        console.error(err);
        setError("Failed to search songs");
      } finally {
        setIsLoading(false);
      }
    }
    searchTracks();
  }, [debouncedQuery]);

  const handleTrackSelect = (track: SpotifyTrack) => {
    setSelectedTrack(track);
    setShowSuggestions(false);
    setQuery(track.name);
  };

  const handleAddSong = async (status: SongStatus) => {
    if (!selectedTrack) {
      setError("No track selected");
      return;
    }

    if (!currentBandId) {
      setError("No active band selected");
      return;
    }

    setIsLoading(true);
    setError(null);

    try {
      const baseSongId = await addBaseSong({
        title: selectedTrack.name,
        artist: selectedTrack.artists.map((a) => a.name).join(", "),
        previewUrl: selectedTrack.preview_url || selectedTrack.external_urls?.spotify || "",
        thumbnail: selectedTrack.album?.images[0]?.url || "", // Fallback for undefined
        metadata: {
          duration: selectedTrack.duration_ms
            ? `${Math.floor(selectedTrack.duration_ms / 60000)}:${((selectedTrack.duration_ms % 60000) / 1000)
              .toFixed(0)
              .padStart(2, "0")}`
            : "00:00", // Default fallback
        },
      });

      // Use the `status` passed to the function
      await addBandSong(baseSongId, currentBandId, status);
      onOpenChange(false);
    } catch (err) {
      console.error(err);
      setError("Failed to add song");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="w-full max-w-[90%] sm:max-w-[425px] h-[calc(100vh-20px)] sm:h-auto overflow-auto bg-background">

        <DialogHeader>
          <DialogTitle>Add Song</DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          <Input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onFocus={() => setShowSuggestions(true)}
            placeholder="Search songs..."
            className="sticky top-0 bg-background"
          />

          {isLoading && <p className="text-sm text-gray-500">Searching...</p>}
          {error && <p className="text-sm text-red-500">{error}</p>}

          {query && showSuggestions && suggestions.length > 0 && (
            <div className="max-h-[40vh] overflow-y-auto space-y-2">
              {suggestions.map((track) => (
                <button
                  key={track.id}
                  onClick={() => handleTrackSelect(track)}
                  className="w-full p-2 flex items-center gap-3 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-lg"
                >
                  <img
                    src={track.album?.images[0]?.url || "/path/to/placeholder-image.png"}
                    alt={track.name || "No image available"}
                    className="w-12 h-12 rounded"
                  />F
                  <div className="text-left">
                    <div className="font-medium">{track.name}</div>
                    <div className="text-sm text-gray-500">
                      {track.artists.map(a => a.name).join(", ")}
                    </div>
                  </div>
                </button>
              ))}
            </div>
          )}

          {selectedTrack && (
            <>
              <iframe
                src={`https://open.spotify.com/embed/track/${selectedTrack.id}`}
                width="100%"
                height="152"
                style={{ borderRadius: '12px' }}
                allow="encrypted-media"
                className="my-4"
              />
              <div className="flex justify-end gap-2">
                <Button
                  variant="outline"
                  onClick={() => handleAddSong("SUGGESTED")}
                  disabled={isLoading}
                  className="hover:bg-blue-500 dark:hover:bg-gray-700"
                >
                  Add to Suggestions
                </Button>
                <Button
                  variant="outline"
                  onClick={() => handleAddSong("PLAYBOOK")}
                  disabled={isLoading}
                  className="hover:bg-orange-500 dark:hover:bg-gray-700"
                >
                  Add to Play Book
                </Button>

              </div>
            </>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}

