// src/components/ui/AddSongButton.tsx
import { PlusCircle, MinusCircle } from 'lucide-react';
import { useState } from 'react';
import AddSongDialog from '@/components/songs/AddSongModal';

export default function AddSongButton() {
  const [open, setOpen] = useState(false);

  const handleToggleDialog = () => {
    setOpen((prev) => !prev);
  };

  return (
    <>
      <button 
        onClick={handleToggleDialog}
        className="absolute top-8 right-4 rounded-full bg-orange-500 p-2 hover:bg-orange-400 transition-colors"
      >
        {open ? (
          <MinusCircle className="w-6 h-6 text-white" />
        ) : (
          <PlusCircle className="w-6 h-6 text-white" />
        )}
      </button>
      <AddSongDialog open={open} onOpenChange={setOpen} />
    </>
  );
}