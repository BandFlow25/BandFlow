// src/app/layout.tsx
import './globals.css'
import type { Metadata } from 'next'
import { Inter } from 'next/font/google'
import { AuthProvider } from '@/contexts/auth/AuthProvider';
import { BandProvider } from '@/contexts/band/BandProvider';

const inter = Inter({ subsets: ['latin'] })

// src/app/layout.tsx
export const metadata: Metadata = {
  title: 'BandFlow25',
  description: 'Managing your cover band song list with BandFlow25!',
  applicationName: 'BandFlow25',
  keywords: ['band management', 'setlist', 'music', 'band', 'rehearsal'],
  authors: [{ name: 'BandFlow25' }],
  creator: 'BandFlow25',
  publisher: 'BandFlow25',
  formatDetection: {
    telephone: false,
    email: false,
    address: false,
  },
  manifest: '/manifest.json',
  appleWebApp: {
    capable: true,
    statusBarStyle: 'default',
    title: 'BandFlow25',
    startupImage: [
      '/startup/apple-splash-2048-2732.jpg',
      '/startup/apple-splash-1668-2388.jpg',
      '/startup/apple-splash-1536-2048.jpg',
      '/startup/apple-splash-1125-2436.jpg',
      '/startup/apple-splash-750-1334.jpg',
    ],
  },
  openGraph: {
    type: 'website',
    siteName: 'BandFlow25',
    title: 'BandFlow25',
    description: 'Managing your cover band song list with BandFlow25!',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'BandFlow25',
    description: 'Managing your cover band song list with BandFlow25!',
  },
  category: 'music',
};

// Correctly placed viewport configuration
export const viewport = {
  width: 'device-width',
  initialScale: 1,
  maximumScale: 1,
  themeColor: [
    { media: '(prefers-color-scheme: light)', color: '#ffffff' },
    { media: '(prefers-color-scheme: dark)', color: '#111827' }
  ],
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <body className={inter.className}>
        <div className="min-h-[100dvh] flex flex-col">
          <AuthProvider>
            <BandProvider>
              {children}
            </BandProvider>
          </AuthProvider>
        </div>
      </body>
    </html>
  )
}