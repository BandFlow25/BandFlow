// src/lib/constants/index.ts
export const APP_NAME = 'BandFlow25';

export const INSTRUMENTS = [
  'Vocals',
  'Guitar',
  'Rhythm Guitar', // Fixed typo in 'Guitar'
  'Bass',
  'Drums',
  'Keys',
  'Percussion',
  'Saxophone',
  'Trumpet',
  'Other'
] as const;

export const ROUTES = {
  HOME: '/',
  LOGIN: '/login',
  REGISTER: '/register',
  BANDS: '/bands',
  PROFILE: '/bands/settings/profile',
} as const;

export const COLLECTIONS = {
  USERS: 'bf_users',
  BANDS: 'bf_bands',
  BAND_SONGS: 'bf_band_songs', // Updated to match our Firebase collection
  SETLISTS: 'setlists',
} as const;

// Base song status types - these are the actual db values
export const SONG_STATUS = {
  SUGGESTED: 'SUGGESTED',
  VOTING: 'VOTING',
  REVIEW: 'REVIEW',
  PRACTICE: 'PRACTICE',
  PLAYBOOK: 'PLAYBOOK',
  DISCARDED: 'DISCARDED',
  PARKED: 'PARKED'
} as const;

// URL-friendly list types for routing
export const SONG_LIST_TYPES = {
  ALL: 'all',
  SUGGESTIONS: 'suggestions',
  VOTING: 'voting',
  REVIEW: 'review',
  PRACTICE: 'practice',
  PLAYBOOK: 'playbook',
  PARKED: 'parked',
  DISCARDED: 'discarded'
} as const;

// Display labels for UI
export const SONG_LIST_LABELS = {
  [SONG_LIST_TYPES.ALL]: 'All Songs',
  [SONG_LIST_TYPES.SUGGESTIONS]: 'Suggestions',
  [SONG_LIST_TYPES.VOTING]: 'In Voting',
  [SONG_LIST_TYPES.REVIEW]: 'In Review',
  [SONG_LIST_TYPES.PRACTICE]: 'Practice List',
  [SONG_LIST_TYPES.PLAYBOOK]: 'Play Book',
  [SONG_LIST_TYPES.PARKED]: 'Parked',
  [SONG_LIST_TYPES.DISCARDED]: 'Discarded'
} as const;

// Mapping between URL types and status values
export const LIST_TYPE_TO_STATUS = {
  [SONG_LIST_TYPES.SUGGESTIONS]: SONG_STATUS.SUGGESTED,
  [SONG_LIST_TYPES.VOTING]: SONG_STATUS.VOTING,
  [SONG_LIST_TYPES.REVIEW]: SONG_STATUS.REVIEW,
  [SONG_LIST_TYPES.PRACTICE]: SONG_STATUS.PRACTICE,
  [SONG_LIST_TYPES.PLAYBOOK]: SONG_STATUS.PLAYBOOK,
  [SONG_LIST_TYPES.PARKED]: SONG_STATUS.PARKED,
  [SONG_LIST_TYPES.DISCARDED]: SONG_STATUS.DISCARDED
} as const;