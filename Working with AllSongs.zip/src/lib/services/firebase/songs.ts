//src\lib\services\firebase\songs.ts
import { collection, doc, getDoc, getDocs, query, where, setDoc, serverTimestamp } from 'firebase/firestore';
import { db } from '@/lib/config/firebase';
import { BaseSong, BandSong } from '@/lib/types/song';
import { SongStatus } from '@/lib/types/types';


const BF_BASE_SONGS = 'bf_base_songs';
const BF_BAND_SONGS = 'bf_band_songs';

export async function addBaseSong(song: Omit<BaseSong, 'id' | 'createdAt' | 'updatedAt'>): Promise<string> {
  const songRef = doc(collection(db, BF_BASE_SONGS));
  const timestamp = serverTimestamp();
  
  await setDoc(songRef, {
    ...song,
    createdAt: timestamp,
    updatedAt: timestamp
  });

  return songRef.id;
}

export async function addBandSong(
  baseSongId: string, 
  bandId: string, 
  status: SongStatus
): Promise<string> {
  const baseSong = await getDoc(doc(db, BF_BASE_SONGS, baseSongId));
  if (!baseSong.exists()) throw new Error('Base song not found');

  const bandSongRef = doc(collection(db, BF_BAND_SONGS));
  const timestamp = serverTimestamp();

  await setDoc(bandSongRef, {
    ...baseSong.data(),
    baseSongId,
    bandId,
    status,
    createdAt: timestamp,
    updatedAt: timestamp
  });

  return bandSongRef.id;
}

export async function getBandSongs(bandId: string): Promise<BandSong[]> {
  const songsQuery = query(
    collection(db, BF_BAND_SONGS),
    where('bandId', '==', bandId)
  );
  
  const snapshot = await getDocs(songsQuery);
  return snapshot.docs.map(doc => ({
    id: doc.id,
    ...doc.data()
  })) as BandSong[];
}

export async function searchBaseSongs(searchQuery: string): Promise<BaseSong[]> {
  const songsRef = collection(db, BF_BASE_SONGS);
  const queryRef = query(
    songsRef,
    where('title', '>=', searchQuery.toLowerCase()),
    where('title', '<=', searchQuery.toLowerCase() + '\uf8ff')
  );
  const snapshot = await getDocs(queryRef);
  return snapshot.docs.map(doc => ({
    id: doc.id,
    ...doc.data()
  })) as BaseSong[];
}