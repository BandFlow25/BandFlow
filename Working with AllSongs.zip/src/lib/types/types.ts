// src/lib/types/types.ts
export type SongStatus =
  | "SUGGESTED"
  | "VOTING"
  | "REVIEW"
  | "PRACTICE"
  | "PLAYBOOK"
  | "DISCARDED"
  | "PARKED";
  

export type MusicalKey =
  | "C" | "C#/Db" | "D" | "D#/Eb" | "E" | "F"
  | "F#/Gb" | "G" | "G#/Ab" | "A" | "A#/Bb" | "B"
  | "Cm" | "C#m/Dbm" | "Dm" | "D#m/Ebm" | "Em" | "Fm"
  | "F#m/Gbm" | "Gm" | "G#m/Abm" | "Am" | "A#m/Bbm" | "Bm";

export interface PlayBookMetadata {
  bpm?: number;
  key?: MusicalKey;
  notes?: string;
  version?: string;
  capo?: number;
  duration?: string;
  tuning?: string;
  lastPracticed?: Date;
  energyLevel?: {
    value: number;
    description: string;
  };
}