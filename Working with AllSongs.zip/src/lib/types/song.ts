// src/lib/types/song.ts
import { Timestamp } from 'firebase/firestore';
import { MusicalKey, PlayBookMetadata, SongStatus } from './types';

export interface BaseSong {
  id: string;
  title: string;
  artist: string;
  previewUrl: string;
  thumbnail?: string;
  metadata?: {  // Make whole metadata object optional
    bpm?: number;
    key?: MusicalKey;
    duration?: string;
  };
  createdAt: Timestamp;
  updatedAt: Timestamp;
}

export interface BandSong extends BaseSong {
  baseSongId: string;
  bandId: string;
  status: SongStatus;
  notes?: string;
  playBookMetadata?: PlayBookMetadata;
}
