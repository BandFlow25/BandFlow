'use client';

import { createContext, useContext, useState, useCallback } from 'react';
import { getBand, isUserBandAdmin } from '@/lib/services/firebase/bands';
import type { Band } from '@/lib/types/band';
import { useAuth } from '@/contexts/auth/AuthProvider';

interface BandContextType {
  activeBand: Band | null;
  currentBandId: string | null;  // Add to interface
  isAdmin: boolean;
  setActiveBandId: (bandId: string | null) => Promise<void>;
  isLoading: boolean;
  error: string | null;
}

const BandContext = createContext<BandContextType | undefined>(undefined);

export function BandProvider({ children }: { children: React.ReactNode }) {
  const { user } = useAuth();
  const [activeBand, setActiveBand] = useState<Band | null>(null);
  const [isAdmin, setIsAdmin] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [currentBandId, setCurrentBandId] = useState<string | null>(null);

  const setActiveBandId = useCallback(async (bandId: string | null) => {
    // Prevent unnecessary updates
    if (bandId === currentBandId || !user) return;

    if (!bandId) {
      setActiveBand(null);
      setIsAdmin(false);
      setCurrentBandId(null);
      return;
    }

    setIsLoading(true);
    setError(null);

    try {
      const [band, adminStatus] = await Promise.all([
        getBand(bandId),
        isUserBandAdmin(user.uid, bandId)
      ]);

      if (!band) {
        throw new Error('Band not found');
      }

      setActiveBand(band);
      setIsAdmin(adminStatus);
      setCurrentBandId(bandId);
    } catch (err: any) {
      setError(err.message || 'Failed to load band');
      setActiveBand(null);
      setIsAdmin(false);
      setCurrentBandId(null);
    } finally {
      setIsLoading(false);
    }
  }, [user]);

  return (
    <BandContext.Provider value={{
      activeBand,
      currentBandId, // Add to value
      isAdmin,
      setActiveBandId,
      isLoading,
      error
    }}>
      {children}
    </BandContext.Provider>
  );
}

export const useBand = () => {
  const context = useContext(BandContext);
  if (context === undefined) {
    throw new Error('useBand must be used within a BandProvider');
  }
  return context;
};