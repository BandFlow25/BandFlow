//src\components\Setlists\SetlistSongCard.tsx
import { useSortable } from '@dnd-kit/sortable';
import { CSS } from '@dnd-kit/utilities';
import { useState, useRef, useEffect } from 'react';
import { cn } from '@/lib/utils';
import { MoreVertical, CornerRightDown, Trash2, Clock } from 'lucide-react';
import type { BandSong } from '@/lib/types/song';
import { DurationtoMinSec } from '@/lib/services/bandflowhelpers/SetListHelpers';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";

interface SetlistSongCardProps {
  id: string;          // Instance ID
  songId: string;      // Reference to original song
  song: BandSong;
  index: number;
  setId: string;
  onRemove?: () => void;
  onToggleSegue?: () => void;
  onSetupTimeChange?: (setupTime: number | null) => void;  // Updated type
  hasSegue?: boolean;
  setupTime?: number | null;  // Updated type
}

export function SetlistSongCard({ 
  id,  // Using instance ID for DnD
  songId,
  song, 
  index, 
  setId,
  onRemove,
  onToggleSegue,
  onSetupTimeChange,
  hasSegue = false,
  setupTime = null  // Updated default
}: SetlistSongCardProps) {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [showSetupTimeModal, setShowSetupTimeModal] = useState(false);
  const [setupTimeInput, setSetupTimeInput] = useState(setupTime?.toString() || '');
  const menuRef = useRef<HTMLDivElement>(null);

  const {
    attributes,
    listeners,
    setNodeRef,
    transform,
    transition,
    isDragging
  } = useSortable({
    id,
    data: {
      type: 'setlist-song',
      songId,
      song,
      index,
      setId
    }
  });

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(event.target as Node)) {
        setIsMenuOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleSetupTimeSubmit = () => {
    const time = setupTimeInput === '' ? null : parseFloat(setupTimeInput);  // Updated to use null
    onSetupTimeChange?.(time);
    setShowSetupTimeModal(false);
  };

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
    opacity: isDragging ? 0.5 : 1,
    touchAction: 'none'
  };

  const isNotPlaybook = song.status !== 'PLAYBOOK';

  return (
    <div
      ref={setNodeRef}
      style={style}
      {...attributes}
      {...listeners}
      className={cn(
        "flex items-center h-8 px-2 rounded-lg group",
        "touch-none select-none cursor-grab active:cursor-grabbing",
        isDragging ? "bg-orange-500/20" : 
          isNotPlaybook ? "bg-orange-500/10 hover:bg-orange-500/20 border border-orange-500/50" : 
          "bg-gray-700/50 hover:bg-gray-700"
      )}
    >
      <span className="w-6 text-xs text-gray-400">{index + 1}</span>
      <div className="flex-1 min-w-0">
        <div className={cn(
          "font-medium text-sm truncate flex items-center gap-1",
          isNotPlaybook ? "text-orange-400" : "text-white"
        )}>
          {song.title}
          {isNotPlaybook && (
            <span className="text-xs">⚠️</span>
          )}
        </div>
      </div>

      {/* Duration display with setup time */}
      {song.metadata?.duration && (
        <div className="flex items-center gap-1">
          {setupTime !== null && (
            <div className="text-xs text-blue-400 ml-2">
              +{setupTime}m
            </div>
          )}
          <div className="text-xs text-gray-400 ml-2">
            {DurationtoMinSec(parseInt(song.metadata.duration))}
          </div>
        </div>
      )}

      {setupTime !== null && (
        <div className="ml-2 text-blue-400">
          <Clock className="w-4 h-4" />
        </div>
      )}

      {hasSegue && (
        <div className="mx-2 text-green-500">
          <CornerRightDown className="w-4 h-4" />
        </div>
      )}

      <div className="relative" ref={menuRef}>
        <button
          onClick={(e) => {
            e.stopPropagation();
            setIsMenuOpen(!isMenuOpen);
          }}
          className={cn(
            "p-1 rounded-full transition-colors",
            isMenuOpen ? "bg-gray-600 text-white" : "text-gray-400 hover:text-white"
          )}
        >
          <MoreVertical className="w-4 h-4" />
        </button>

        {isMenuOpen && (
          <div className="absolute right-0 top-8 bg-gray-800 rounded-lg shadow-lg border border-gray-700 w-40 py-1 z-50">
            <button
              onClick={(e) => {
                e.stopPropagation();
                onToggleSegue?.();
                setIsMenuOpen(false);
              }}
              className="w-full px-3 py-2 text-sm text-left text-gray-300 hover:bg-gray-700 flex items-center gap-2"
            >
              <CornerRightDown className="w-4 h-4" />
              {hasSegue ? "Remove Segue" : "Add Segue"}
            </button>
            <button
              onClick={(e) => {
                e.stopPropagation();
                setShowSetupTimeModal(true);
                setIsMenuOpen(false);
              }}
              className="w-full px-3 py-2 text-sm text-left text-gray-300 hover:bg-gray-700 flex items-center gap-2"
            >
              <Clock className="w-4 h-4" />
              {setupTime !== null ? "Change Setup Time" : "Add Setup Time"}
            </button>
            <button
              onClick={(e) => {
                e.stopPropagation();
                onRemove?.();
                setIsMenuOpen(false);
              }}
              className="w-full px-3 py-2 text-sm text-left text-red-400 hover:bg-gray-700 flex items-center gap-2"
            >
              <Trash2 className="w-4 h-4" />
              Remove
            </button>
          </div>
        )}
      </div>

      {/* Setup Time Modal */}
      <Dialog open={showSetupTimeModal} onOpenChange={setShowSetupTimeModal}>
        <DialogContent className="bg-gray-900 border border-gray-800">
          <DialogHeader>
            <DialogTitle>
              {setupTime !== null ? "Change Setup Time" : "Add Setup Time"}
            </DialogTitle>
          </DialogHeader>
          
          <div className="py-4">
            <label className="block text-sm font-medium text-gray-200 mb-2">
              Setup time needed (minutes)
            </label>
            <Input 
              type="number"
              step="0.5"
              min="0"
              value={setupTimeInput}
              onChange={(e) => setSetupTimeInput(e.target.value)}
              placeholder="Enter time in minutes"
              className="bg-gray-800 border-gray-700"
            />
          </div>

          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => {
                onSetupTimeChange?.(null);
                setShowSetupTimeModal(false);
              }}
              className="bg-gray-800 hover:bg-gray-700"
            >
              {setupTime !== null ? "Remove Setup Time" : "Cancel"}
            </Button>
            <Button
              onClick={handleSetupTimeSubmit}
              className="bg-orange-500 hover:bg-orange-600"
              disabled={setupTimeInput === ''}
            >
              Save
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}