// app/bands/[bandId]/setlists/[setlistId]/page.tsx
'use client';

import { useEffect, useState } from 'react';
import { useParams } from 'next/navigation';
import { useBand } from '@/contexts/BandProvider';
import { useSetlist } from '@/contexts/SetlistProvider';
import type { Setlist } from '@/lib/types/setlist';
import type { BandSong } from '@/lib/types/song';
import PageLayout from '@/components/layout/PageLayout';
import { Clock, ListMusic, GripVertical } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { doc, getDoc } from 'firebase/firestore';
import { db } from '@/lib/config/firebase';

interface SetlistWithSongDetails extends Setlist {
    songDetails: Record<string, BandSong>;
}

async function fetchSongDetails(bandId: string, songId: string): Promise<BandSong | null> {
    try {
        const songDoc = await getDoc(doc(db, 'bf_band_songs', songId));
        if (!songDoc.exists()) return null;
        return { id: songDoc.id, ...songDoc.data() } as BandSong;
    } catch (error) {
        console.error('Error fetching song details:', error);
        return null;
    }
}

export default function SetlistDetailsPage() {
    const { setActiveBandId, activeBand, isLoading } = useBand();
    const { setlist, isLoading: isLoadingSetlist, error } = useSetlist(); // Use the SetlistProvider
    const params = useParams();
    const bandId = params?.bandId as string;
    const setlistId = params?.setlistId as string;
  
    const [isLoadingSongs, setIsLoadingSongs] = useState(true);
  
    useEffect(() => {
      if (bandId) {
        setActiveBandId(bandId);
      }
    }, [bandId, setActiveBandId]);
  
    useEffect(() => {
      if (!isLoadingSetlist && setlist) {
        setIsLoadingSongs(false);
      }
    }, [isLoadingSetlist, setlist]);
  
    useEffect(() => {
      const loadSetlistAndSongs = async () => {
        console.log('Initializing loadSetlistAndSongs...');
        console.log('bandId:', bandId);
        console.log('setlistId:', setlistId);
  
        if (!bandId || !setlistId) {
          console.warn('Missing bandId or setlistId. Exiting loadSetlistAndSongs.');
          return;
        }
  
        try {
          console.log('Fetching setlist data...');
          const data = setlist; // Setlist is now provided by the SetlistProvider
  
          if (!data) {
            console.warn('No setlist data found for:', { bandId, setlistId });
            setIsLoadingSongs(false);
            return;
          }
  
          console.log('Setlist data retrieved:', data);
  
          // Load song details
          const songDetails: Record<string, BandSong> = {};
          console.log('Fetching song details...');
          await Promise.all(
            data.songs.map(async (song) => {
              console.log('Fetching details for songId:', song.songId);
              const details = await fetchSongDetails(bandId, song.songId);
              if (details) {
                console.log('Details retrieved for songId:', song.songId, details);
                songDetails[song.songId] = details;
              } else {
                console.warn('No details found for songId:', song.songId);
              }
            })
          );
  
          console.log('Updating setlist with song details:', songDetails);
        } catch (error) {
          console.error('Error loading setlist:', error);
          setIsLoadingSongs(false);
        }
      };
  
      loadSetlistAndSongs();
    }, [bandId, setlistId, setlist]);
  
    if (isLoading || isLoadingSetlist) {
      return <div className="min-h-screen bg-gray-900" />;
    }
  
    if (error) {
      return (
        <div className="min-h-screen bg-gray-900 flex items-center justify-center">
          <div className="text-white">{error}</div>
        </div>
      );
    }
  
    if (!setlist) {
      return (
        <div className="min-h-screen bg-gray-900 flex items-center justify-center">
          <div className="text-white">Setlist not found</div>
        </div>
      );
    }
  
    return (
      <PageLayout title={setlist.name}>
        <div className="p-4">
          {/* Setlist Info */}
          <div className="bg-gray-800 rounded-lg p-4 mb-6">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h2 className="text-xl font-semibold text-white">{setlist.name}</h2>
                <div className="flex items-center gap-4 mt-2 text-gray-400">
                  <div className="flex items-center gap-1">
                    <ListMusic className="w-4 h-4" />
                    <span>{setlist.songs.length} songs</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <Clock className="w-4 h-4" />
                    <span>
                      {setlist.format.numSets} sets, {setlist.format.setDuration}min each
                    </span>
                  </div>
                </div>
              </div>
              <Button
                variant="outline"
                className="text-orange-500 border-orange-500 hover:bg-orange-500/10"
              >
                Add Songs
              </Button>
            </div>
          </div>
  
          {/* Sets */}
          {Array.from({ length: setlist.format.numSets }).map((_, setIndex) => {
            const setNumber = setIndex + 1;
            const setSongs = setlist.songs.filter((song) => song.setNumber === setNumber);
  
            return (
              <div key={setNumber} className="mb-8">
                <h3 className="text-lg font-medium text-white mb-4">
                  Set {setNumber}
                  <span className="text-sm text-gray-400 ml-2">
                    ({setSongs.length} songs)
                  </span>
                </h3>
  
                {setSongs.length > 0 ? (
                  <div className="space-y-1">
                    {setSongs.map((song, index) => (
                      <div
                        key={song.songId}
                        className="bg-gray-800/50 p-3 rounded flex items-center justify-between group"
                      >
                        <div className="flex items-center gap-2">
                          <GripVertical className="w-4 h-4 text-gray-600 opacity-0 group-hover:opacity-100 cursor-grab" />
                          <span className="text-gray-500 w-6">{index + 1}</span>
                          <span className="text-white">
                            {isLoadingSongs ? (
                              <span className="animate-pulse">Loading...</span>
                            ) : (
                              setlist.songDetails[song.songId]?.title || 'Unknown Song'
                            )}
                          </span>
                        </div>
                        <span className="text-gray-500">
                          {setlist.songDetails[song.songId]?.metadata?.duration || '--:--'}
                        </span>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-8 bg-gray-800/30 rounded-lg">
                    <p className="text-gray-400">No songs in this set</p>
                    <Button
                      variant="outline"
                      className="mt-2 text-orange-500 border-orange-500 hover:bg-orange-500/10"
                    >
                      Add Songs to Set {setNumber}
                    </Button>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </PageLayout>
    );
  }