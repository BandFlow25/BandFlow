// src/app/api/metadata/route.ts
import { NextResponse } from 'next/server';
import OpenAI from 'openai';

console.log('API Key exists:', !!process.env.OPENAI_API_KEY);

let openai: OpenAI | null = null;
try {
  if (!process.env.OPENAI_API_KEY) {
    throw new Error('OPENAI_API_KEY is not defined');
  }
  
  openai = new OpenAI({
    apiKey: process.env.OPENAI_API_KEY
  });
  console.log('OpenAI initialized successfully');
} catch (error) {
  console.error('Failed to initialize OpenAI:', error);
}

export async function POST(request: Request) {
  if (!openai) {
    console.error('OpenAI instance is not available');
    return NextResponse.json(
      { error: 'OpenAI configuration error' }, 
      { status: 500 }
    );
  }

  try {
    const { title, artist } = await request.json();
    
    if (!title || !artist) {
      return NextResponse.json(
        { error: 'Title and artist are required' }, 
        { status: 400 }
      );
    }

    const completion = await openai.chat.completions.create({
      model: "gpt-3.5-turbo",
      messages: [
        {
          role: "system",
          content: `You are a music theory and analysis expert. Respond only with a strict JSON object containing the following fields: 'key' (musical key), and 'bpm' (tempo in beats per minute). When determining the key:
    - Default to the original studio recording unless otherwise specified.
    - Avoid assuming the key if uncertain; instead, return "unknown".
    - Use common key detection methods based on chord progressions, tonal centers, or standard references.
    
    If data is unavailable, explicitly return "unknown" for the missing value. Do not attempt to infer if insufficient context is available.`
        },
        {
          role: "user",
          content: `What is the musical key and bpm for "${title}" by ${artist}?`
        }
      ],
      response_format: { type: "json_object" }
    });
    

    const content = completion.choices[0]?.message?.content;
    if (!content) {
      throw new Error('No content in completion response');
    }

    return NextResponse.json(JSON.parse(content));
  } catch (error) {
    console.error('Error in metadata API:', error);
    return NextResponse.json(
      { error: 'Failed to fetch metadata' }, 
      { status: 500 }
    );
  }
}