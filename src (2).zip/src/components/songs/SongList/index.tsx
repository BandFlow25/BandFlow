// components/songs/SongList/index.tsx
import { useMemo, useState } from 'react';
import { useSongs } from '@/contexts/SongProvider';
import { useAuth } from '@/contexts/AuthProvider';
import { SearchHeader } from '../Shared/SearchHeader';
import { Filter } from 'lucide-react';
import { cn } from '@/lib/utils';
import { SongListContent } from './SongListContent';
import { 
  SONG_STATUS, 
  SONG_LIST_TYPES,
  type SongListType 
} from '@/lib/types/song';

interface SongListProps {
  type: SongListType;
}

export function SongList({ type }: SongListProps) {
  const { songs, isLoading, error, searchQuery, setSearchQuery } = useSongs();
  const { user } = useAuth();
  const [statusFilter, setStatusFilter] = useState<string | null>(null);

  const filteredAndSortedSongs = useMemo(() => {
    let filtered = songs;

    // First apply type-specific filtering
    switch(type) {
      case SONG_LIST_TYPES.SUGGESTIONS:
        // Combined Suggested & Review view
        filtered = songs.filter(song => 
          song.status === SONG_STATUS.SUGGESTED || 
          song.status === SONG_STATUS.REVIEW
        );
        
        // Apply status filter if present
        if (statusFilter) {
          filtered = filtered.filter(song => song.status === statusFilter);
        }
    
        // Sort: unvoted SUGGESTED songs first
        filtered.sort((a, b) => {
          // User's unvoted items first
          if (a.status === SONG_STATUS.SUGGESTED && user?.uid) {
            const aVoted = Boolean(a.votes?.[user.uid]);
            const bVoted = Boolean(b.votes?.[user.uid]);
            if (!aVoted && bVoted) return -1;
            if (aVoted && !bVoted) return 1;
          }
          return 0;
        });
        break;
    
      case SONG_LIST_TYPES.ALL:
        // Show all non-playbook songs
        filtered = songs.filter(song => song.status !== SONG_STATUS.PLAYBOOK);
        // Apply parked/discarded filter if present
        if (statusFilter) {
          filtered = filtered.filter(song => song.status === statusFilter);
        }
        break;
    
        case SONG_LIST_TYPES.PRACTICE:
          filtered = songs.filter(song => song.status === SONG_STATUS.PRACTICE);
          filtered.sort((a, b) => {
            if (!user?.uid) return 0;
            
            // Get RAG statuses or default to "GREY"
            const aRag = a.ragStatus?.[user.uid]?.status || 'GREY';
            const bRag = b.ragStatus?.[user.uid]?.status || 'GREY';
            
            // RAG order: GREY -> RED -> AMBER -> GREEN
            const ragOrder = { 'GREY': -1, 'RED': 0, 'AMBER': 1, 'GREEN': 2 };
        
            // Compare based on RAG order
            return ragOrder[aRag] - ragOrder[bRag];
          });
          break;
    }

    // Apply search filter last
    if (searchQuery) {
      const search = searchQuery.toLowerCase();
      filtered = filtered.filter(song =>
        song.title.toLowerCase().includes(search) ||
        song.artist.toLowerCase().includes(search)
      );
    }

    return filtered;
  }, [songs, type, statusFilter, searchQuery, user?.uid]);

  return (
    <div className="flex flex-col h-full">
      <SearchHeader
        searchQuery={searchQuery}
        onSearchChange={setSearchQuery}
        placeholder={`Search ${type} songs...`}
      >
        {/* Active songlist gets filter buttons */}
        {type === SONG_LIST_TYPES.ALL && (
          <div className="flex gap-2 items-center mt-3">
            <Filter className="w-4 h-4 text-gray-400" />
            <div className="flex gap-2 overflow-x-auto pb-1">
              <button
                onClick={() => setStatusFilter(null)}
                className={cn(
                  "px-3 py-1 rounded-full text-sm whitespace-nowrap",
                  !statusFilter
                    ? "bg-orange-500 text-white"
                    : "bg-gray-800 text-gray-400 hover:bg-gray-700 hover:text-white"
                )}
              >
                Active
              </button>
              <button
                onClick={() => setStatusFilter(SONG_STATUS.PARKED)}
                className={cn(
                  "px-3 py-1 rounded-full text-sm whitespace-nowrap",
                  statusFilter === SONG_STATUS.PARKED
                    ? "bg-orange-500 text-white"
                    : "bg-gray-800 text-gray-400 hover:bg-gray-700 hover:text-white"
                )}
              >
                Parked
              </button>
              <button
                onClick={() => setStatusFilter(SONG_STATUS.DISCARDED)}
                className={cn(
                  "px-3 py-1 rounded-full text-sm whitespace-nowrap",
                  statusFilter === SONG_STATUS.DISCARDED
                    ? "bg-orange-500 text-white"
                    : "bg-gray-800 text-gray-400 hover:bg-gray-700 hover:text-white"
                )}
              >
                Discarded
              </button>
            </div>
          </div>
        )}
  
        {/* Pipeline songlist gets filter buttons */}
        {type === SONG_LIST_TYPES.SUGGESTIONS && (
          <div className="flex gap-2 items-center mt-3">
            <Filter className="w-4 h-4 text-gray-400" />
            <div className="flex gap-2 overflow-x-auto pb-1">
              <button
                onClick={() => setStatusFilter(null)}
                className={cn(
                  "px-3 py-1 rounded-full text-sm whitespace-nowrap",
                  !statusFilter
                    ? "bg-orange-500 text-white"
                    : "bg-gray-800 text-gray-400 hover:bg-gray-700 hover:text-white"
                )}
              >
                All Pipeline
              </button>
              <button
                onClick={() => setStatusFilter(SONG_STATUS.SUGGESTED)}
                className={cn(
                  "px-3 py-1 rounded-full text-sm whitespace-nowrap",
                  statusFilter === SONG_STATUS.SUGGESTED
                    ? "bg-orange-500 text-white"
                    : "bg-gray-800 text-gray-400 hover:bg-gray-700 hover:text-white"
                )}
              >
                In Voting
              </button>
              <button
                onClick={() => setStatusFilter(SONG_STATUS.REVIEW)}
                className={cn(
                  "px-3 py-1 rounded-full text-sm whitespace-nowrap",
                  statusFilter === SONG_STATUS.REVIEW
                    ? "bg-orange-500 text-white"
                    : "bg-gray-800 text-gray-400 hover:bg-gray-700 hover:text-white"
                )}
              >
                In Review
              </button>
            </div>
          </div>
        )}
      </SearchHeader>
  
      <div className="flex-1 overflow-y-auto">
        <SongListContent
          songs={filteredAndSortedSongs}
          isLoading={isLoading}
          error={error}
          listType={type}
        />
      </div>
    </div>
  );
}