// components/songs/SongCard/BaseSongCard.tsx
import { useState, useMemo } from 'react';
import { Music, Play, Trash2, ThumbsDown, ListChecks, PauseCircle, XCircle, BookOpen } from 'lucide-react';
import { cn } from '@/lib/utils';
import type { BandSong, SongListType } from '@/lib/types/song';
import { SongCardActions } from './SongCardActions';
import { addVote, updateRagStatus, updateSongStatus, deleteBandSong } from '@/lib/services/firebase/songs';
import { usePlayerContext } from "@/contexts/PlayerContext";
import { VotingControls } from '@/components/songs/Features/VotingControls';
import { useBand } from '@/contexts/BandProvider';
import { useAuth } from '@/contexts/AuthProvider';
import { MetadataDisplay } from '@/components/songs/Features/MetadataDisplay';
import { RAGStatus, SongStatus } from '@/lib/types/song';
import { RAGStatusControls } from '@/components/songs/Features/RagStatusControls';
import { SONG_STATUS } from '@/lib/types/song';

interface BaseSongCardProps {
  song: BandSong;
  type: SongListType;
  onSongDeleted?: (() => void) | undefined;
  className?: string;
}

export function BaseSongCard({
  song,
  type,
  className,
  onSongDeleted
}: BaseSongCardProps) {
  const [isHovered, setIsHovered] = useState(false);
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const { setCurrentSong, setIsPlaying } = usePlayerContext();
  const { user } = useAuth();
  const { activeBand, isAdmin, memberCount } = useBand();
  const voteCount = Object.keys(song.votes || {}).length;
  const hasUserVoted = user ? !!song.votes?.[user.uid] : false;

  const needsUserAction = useMemo(() => {
    if (!user?.uid) return false;

    switch (song.status) {
      case SONG_STATUS.PRACTICE:
        return !song.ragStatus?.[user.uid];
      case SONG_STATUS.SUGGESTED:
        return !hasUserVoted;
      default:
        return false;
    }
  }, [song.status, song.votes, song.ragStatus, user?.uid, hasUserVoted]);

  const handleVote = async (score: number) => {
    if (!user || !activeBand?.id) return;
    try {
      await addVote(activeBand.id, song.id, user.uid, score);
      setIsMenuOpen(false);
    } catch (error) {
      console.error('Error in handleVote:', error);
    }
  };

  const handleStatusChange = async (newStatus: SongStatus) => {
    if (!user || !activeBand?.id) return;
    try {
      await updateSongStatus(activeBand.id, song.id, user.uid, newStatus);
      setIsMenuOpen(false);
    } catch (error) {
      console.error('Error updating song status:', error);
    }
  };

  const handleRagStatusUpdate = async (status: RAGStatus) => {
    if (!user || !activeBand?.id) return;
    try {
      await updateRagStatus(activeBand.id, song.id, user.uid, status);
      setIsMenuOpen(false);
    } catch (error) {
      console.error('Error updating RAG status:', error);
    }
  };

  const handleDelete = async (e: React.MouseEvent) => {
    e.stopPropagation();
    if (!user || !activeBand?.id) return;
    try {
      await deleteBandSong(activeBand.id, song.id, user.uid);
      onSongDeleted?.();
    } catch (error) {
      console.error('Error deleting song:', error);
    }
  };

  const getStatusStyles = (status: string) => {
    switch (status) {
      case 'PARKED':
        return 'bg-blue-900/20 hover:bg-blue-900/30';
      case 'DISCARDED':
        return 'bg-red-900/20 hover:bg-red-900/30';
      default:
        return 'bg-gray-800/40 hover:bg-gray-800/60';
    }
  };

  const calculateScore = (votes: Record<string, { value: number }> | undefined) => {
    if (!votes || !activeBand) return 0;
    const totalVotes = Object.values(votes).reduce((sum, vote) => sum + vote.value, 0);
    const maxPossibleScore = (song.votingMemberCount || memberCount) * 5;
    return Math.round((totalVotes / maxPossibleScore) * 100);
  };

  const getDownVoters = (votes: Record<string, { value: number }> | undefined) => {
    if (!votes) return [];
    return Object.entries(votes)
      .filter(([_, vote]) => vote.value === 0)
      .map(([userId]) => userId);
  };


  return (
    <div
      className={cn(
        "group relative flex items-center gap-2 py-1.5 px-2 rounded-md",
        needsUserAction ? "border border-orange-500/50" : "",
        getStatusStyles(song.status),
        "transition-all duration-200 ease-in-out hover:shadow-lg",
        className
      )}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => {
        setIsHovered(false);
        setIsMenuOpen(false);
      }}
    >
      {/* Thumbnail */}
      <div className="relative min-w-[36px] w-[36px] h-[36px] transition-transform duration-200 ease-in-out group-hover:scale-105">
        {song.thumbnail ? (
          <img
            src={song.thumbnail}
            alt={song.title}
            className="w-full h-full rounded-md object-cover"
          />
        ) : (
          <div className="w-full h-full rounded-md bg-gray-700/50 flex items-center justify-center">
            <Music className="w-5 h-5 text-gray-400" />
          </div>
        )}
        <button
          className="absolute inset-0 flex items-center justify-center bg-black/40 rounded-md opacity-0 group-hover:opacity-100"
          onClick={(e) => {
            e.stopPropagation();
            setCurrentSong(song);
            setIsPlaying(true);
          }}
        >
          <Play className="w-5 h-5 text-white" />
        </button>
        {isAdmin && (
          <button
            onClick={handleDelete}
            className="absolute top-1 right-1 p-1 rounded-full bg-black/50 hover:bg-black/70 transition-colors"
            title="Delete Song"
          >
            <Trash2 className="w-3.5 h-3.5 text-red-400" />
          </button>
        )}
      </div>

      {/* Title and Info */}
      <div className="flex-1 min-w-0 flex flex-col justify-center">
        <div className="flex items-center gap-2">
          <h3 className="font-medium text-white truncate text-sm leading-tight">{song.title}</h3>
          {song.status === SONG_STATUS.SUGGESTED && (
            <span className="text-xs text-gray-400">
              {voteCount}/{memberCount}
            </span>
          )}
          {song.status === SONG_STATUS.REVIEW && (
            <div className="flex items-center gap-1 text-xs text-gray-400">
              <span>{calculateScore(song.votes)}%</span>
              {getDownVoters(song.votes).length > 0 && (
                <ThumbsDown className="w-3 h-3 text-red-400" />
              )}
              {calculateScore(song.votes) >= 85 && (
                <span>🔥</span>
              )}
            </div>
          )}
        </div>
        <p className="text-xs text-gray-400 truncate">{song.artist}</p>
      </div>

      {/* Metadata and Actions */}
      <div className="flex items-center gap-2 shrink-0">
        <MetadataDisplay song={song} />
        <SongCardActions 
          onOpenMenu={() => setIsMenuOpen(!isMenuOpen)}
          className="scale-90 sm:scale-100"
        />
      </div>

      {/* Menu Overlay */}
      {isMenuOpen && (
        <div
          className={cn(
            "absolute inset-0 bg-gray-800/95 rounded-md p-4",
            "flex items-center justify-center",
            "transform transition-all duration-200 ease-in-out z-10",
            "animate-in fade-in zoom-in-95 duration-200"
          )}
        >
          {song.status === SONG_STATUS.SUGGESTED ? (
            <VotingControls
              currentVote={song.votes?.[user?.uid ?? '']?.value ?? null}
              onVote={handleVote}
            />
          ) : song.status === SONG_STATUS.REVIEW ? (
            <div className="flex items-center gap-3">
              <button
                onClick={() => handleStatusChange(SONG_STATUS.PRACTICE)}
                className="flex items-center gap-2 px-4 py-2 bg-green-500/20 text-green-400 hover:bg-green-500/30 rounded-lg transition-all duration-200 hover:scale-105 active:scale-95"
              >
                <ListChecks className="w-5 h-5" />
                Practice
              </button>
              <button
                onClick={() => handleStatusChange(SONG_STATUS.PARKED)}
                className="flex items-center gap-2 px-4 py-2 bg-blue-500/20 text-blue-400 hover:bg-blue-500/30 rounded-lg transition-all duration-200 hover:scale-105 active:scale-95"
              >
                <PauseCircle className="w-5 h-5" />
                Park
              </button>
              <button
                onClick={() => handleStatusChange(SONG_STATUS.DISCARDED)}
                className="flex items-center gap-2 px-4 py-2 bg-red-500/20 text-red-400 hover:bg-red-500/30 rounded-lg transition-all duration-200 hover:scale-105 active:scale-95"
              >
                <XCircle className="w-5 h-5" />
                Discard
              </button>
            </div>
          ) : song.status === SONG_STATUS.PRACTICE && (
            <div className="flex flex-col items-center gap-3">
              <RAGStatusControls
                currentStatus={song.ragStatus?.[user?.uid ?? '']?.status ?? null}
                onChange={handleRagStatusUpdate}
              />
              <div className="flex items-center gap-2">
                <button
                  onClick={() => handleStatusChange(SONG_STATUS.PLAYBOOK)}
                  className="flex items-center gap-2 px-3 py-1.5 bg-green-500/20 text-green-400 hover:bg-green-500/30 rounded-lg transition-all duration-200 hover:scale-105 active:scale-95"
                >
                  <BookOpen className="w-4 h-4" />
                  Playbook
                </button>
                <button
                  onClick={() => handleStatusChange(SONG_STATUS.PARKED)}
                  className="flex items-center gap-2 px-3 py-1.5 bg-yellow-500/20 text-yellow-400 hover:bg-yellow-500/30 rounded-lg transition-all duration-200 hover:scale-105 active:scale-95"
                >
                  <PauseCircle className="w-4 h-4" />
                  Park
                </button>
                <button
                  onClick={() => handleStatusChange(SONG_STATUS.DISCARDED)}
                  className="flex items-center gap-2 px-3 py-1.5 bg-red-500/20 text-red-400 hover:bg-red-500/30 rounded-lg transition-all duration-200 hover:scale-105 active:scale-95"
                >
                  <XCircle className="w-4 h-4" />
                  Discard
                </button>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}