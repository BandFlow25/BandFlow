import { useSortable } from '@dnd-kit/sortable';
import { CSS } from '@dnd-kit/utilities';
import { useSpring, animated } from '@react-spring/web';
import { useDrag } from '@use-gesture/react';
import type { BandSong } from '@/lib/types/song';
import { DurationtoMinSec } from '@/lib/services/bandflowhelpers/SetListHelpers';
import { cn } from '@/lib/utils';
import { X } from 'lucide-react';

interface SetlistSongCardProps {
  id: string;
  song: BandSong;
  index: number;
  setId: string;
  onRemove?: () => void;
}

const AnimatedDiv = animated('div' as any);

export function SetlistSongCard({ id, song, index, setId, onRemove }: SetlistSongCardProps) {
  const {
    attributes,
    listeners,
    setNodeRef,
    transform,
    transition,
    isDragging,
  } = useSortable({
    id,
    data: {
      type: 'setlist-song',
      song,
      index,
      setId,
    },
  });

  const [{ x }, api] = useSpring(() => ({ x: 0 }));

  const bindDrag = useDrag(
    ({ down, movement: [mx], velocity: [vx] }) => {
      if (Math.abs(mx) < 5) return;

      const isSwipeLeft = mx < 0;

      if (down) {
        if (isSwipeLeft) {
          api.start({ x: mx, immediate: true });
        }
      } else {
        const swipeThreshold = -100;
        const velocityThreshold = 0.5;

        if (mx < swipeThreshold && vx < -velocityThreshold) {
          api.start({
            x: -200,
            onResolve: () => {
              if (onRemove) {
                onRemove();
              }
            },
          });
        } else {
          api.start({ x: 0 });
        }
      }
    },
    {
      axis: 'x',
      bounds: { left: -200, right: 0 },
      rubberband: true,
    }
  );

  const sortableStyle = {
    transform: CSS.Transform.toString(transform),
    transition,
  };

  return (
    <AnimatedDiv
      ref={setNodeRef}
      {...attributes}
      {...listeners}
      {...bindDrag()}
      style={{
        ...sortableStyle,
        x,
        opacity: isDragging ? 0.5 : 1,
        touchAction: 'pan-y',
      }}
      className={cn(
        'flex items-center h-8 px-2 rounded-lg relative',
        'touch-none select-none cursor-grab active:cursor-grabbing',
        isDragging ? 'bg-orange-500/20' : 'bg-gray-700/50 hover:bg-gray-700'
      )}
    >
      <div
        className={cn(
          'absolute inset-y-0 -right-2 flex items-center justify-center w-12',
          'bg-red-500/10 text-red-500'
        )}
      >
        <X className="w-4 h-4" />
      </div>

      <span className="w-6 text-xs text-gray-400">{index + 1}</span>
      <div className="flex-1 min-w-0">
        <div className="font-medium text-white text-sm truncate">{song.title}</div>
      </div>
      {song.metadata?.duration && (
        <div className="text-xs text-gray-400 ml-2">
          {DurationtoMinSec(parseInt(song.metadata.duration))}
        </div>
      )}
    </AnimatedDiv>
  );
}
