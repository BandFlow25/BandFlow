// src/app/bands/[bandId]/setlists/[setlistId]/page.tsx
'use client';

import { useEffect, useState } from 'react';
import { useParams } from 'next/navigation';
import { useBand } from '@/contexts/BandProvider';
import { getSetlist, updateSetlistSets } from '@/lib/services/firebase/setlists';
import { DndContext, DragEndEvent, DragOverEvent, DragStartEvent } from '@dnd-kit/core';
import { arrayMove } from '@dnd-kit/sortable';
import type { Setlist } from '@/lib/types/setlist';
import { Clock, ArrowLeft, Plus } from 'lucide-react';
import Link from 'next/link';
import { SetlistSet } from '@/components/Setlists/SetlistSet';
import { AddSongsModal } from '@/components/Setlists/AddSongsModal';
import { toast } from 'react-hot-toast';
import type { BandSong } from '@/lib/types/song';

export default function SetlistViewPage() {
    const params = useParams();
    console.log('Params:', params);
    const { activeBand } = useBand();
    const [setlist, setSetlist] = useState<Setlist | null>(null);
    const [isLoading, setIsLoading] = useState(true);
    const [activeSetId, setActiveSetId] = useState<string | null>(null);
    const [isAddSongsOpen, setIsAddSongsOpen] = useState(false);
    const [playbookSongs, _setPlaybookSongs] = useState<BandSong[]>([]);
    const [selectedSetId, setSelectedSetId] = useState<string | null>(null);

    const setlistId = typeof params.setlistid === 'string' ? params.setlistid : params.setlistid?.[0];


    console.log('Setlist:', setlist);
    console.log('Setlist Sets:', setlist?.sets);
    setlist?.sets?.forEach((set, index) => {
        console.log(`Set ${index + 1}:`, set);
        console.log('Set Songs:', set.songs);
    });


    const existingSongIds = new Set(
        setlist?.sets?.flatMap(set => set.songs?.map(song => song.songId) || []) || []
    );

    useEffect(() => {
        loadSetlist();
    }, [setlistId, activeBand?.id]);

    const handleAddSongs = async (songIds: string[]) => {
        if (!setlist || !selectedSetId || !activeBand?.id || !setlistId) {
            toast.error('Invalid band, setlist, or selected set ID');
            return;
        }

        const targetSet = setlist.sets.find(set => set.id === selectedSetId);
        if (!targetSet || !targetSet.id) {
            toast.error('Target set or set ID not found');
            return;
        }

        const newSets = setlist.sets.map(set => {
            if (set.id === selectedSetId) {
                return {
                    ...set,
                    songs: [
                        ...set.songs,
                        ...songIds.map((songId, index) => ({
                            songId,
                            setNumber: parseInt(targetSet.id.split('-')[1] || '1', 10), // Ensure split returns a valid string
                            position: set.songs.length + index
                        }))
                    ]
                };
            }
            return set;
        });

        try {
            await updateSetlistSets(activeBand.id, setlistId, newSets); // Safe here because setlistId is checked
            setSetlist({ ...setlist, sets: newSets });
            toast.success('Songs added to setlist');
        } catch (error) {
            console.error('Error adding songs:', error);
            toast.error('Failed to add songs');
        }
    };

    const loadSetlist = async () => {
        console.log('Active Band:', activeBand);
        console.log('Setlist ID:', setlistId);

        if (!activeBand?.id || !setlistId) {
            toast.error('Invalid band or setlist');
            return;
        }

        try {
            const data = await getSetlist(activeBand.id, setlistId);
            console.log('Fetched Setlist Data:', JSON.stringify(data, null, 2));
            setSetlist(data);
        } catch (error) {
            console.error('Error loading setlist:', error);
        } finally {
            setIsLoading(false);
        }
    };

    const handleDragStart = (event: DragStartEvent) => {
        const { active } = event;
        const activeSet = setlist?.sets.find(set =>
            set.songs.some(song => song.songId === active.id)
        );
        if (activeSet) {
            setActiveSetId(activeSet.id);
        }
    };

    const handleDragOver = (event: DragOverEvent) => {
        if (!setlist || !activeBand?.id || !setlistId) {
            toast.error('Invalid band or setlist');
            return;
        }

        const { active, over } = event;
        if (!over || !over.id || !active.id) {
            return;
        }

        const activeSet = setlist.sets.find(set =>
            set.songs.some(song => song.songId === active.id)
        );
        const overSet = setlist.sets.find(set => set.id === over.id);

        if (!activeSet || !overSet || activeSet.id === overSet.id) {
            return;
        }

        setSetlist(prevSetlist => {
            if (!prevSetlist) return null;

            const newSets = prevSetlist.sets.map(set => {
                if (set.id === activeSet.id) {
                    return {
                        ...set,
                        songs: set.songs.filter(song => song.songId !== active.id),
                    };
                }
                if (set.id === overSet.id) {
                    const setNumber = parseInt(overSet.id.split('-')[1] || '1', 10);
                    return {
                        ...set,
                        songs: [
                            ...set.songs,
                            {
                                songId: active.id.toString(), // Ensure `songId` is a string
                                setNumber,
                                position: set.songs.length,
                            },
                        ],
                    };
                }
                return set;
            });

            return { ...prevSetlist, sets: newSets };
        });
    };

    const handleDragEnd = async (event: DragEndEvent) => {
        const { active, over } = event;
        if (!over || !setlist || !activeBand?.id || !setlistId) {
            toast.error('Invalid band or setlist');
            return;
        }

        const activeSet = setlist.sets.find(set =>
            set.songs.some(song => song.songId === active.id)
        );
        const overSet = setlist.sets.find(set => set.id === over.id);

        if (!activeSet || !overSet) return;

        if (activeSet.id === overSet.id) {
            const oldIndex = activeSet.songs.findIndex(song => song.songId === active.id);
            const newIndex = overSet.songs.findIndex(song => song.songId === over.id);

            const newSets = setlist.sets.map(set => {
                if (set.id === activeSet.id) {
                    return {
                        ...set,
                        songs: arrayMove(set.songs, oldIndex, newIndex)
                    };
                }
                return set;
            });

            setSetlist({ ...setlist, sets: newSets });

            try {
                await updateSetlistSets(activeBand.id, setlistId, newSets);
            } catch (error) {
                console.error('Error updating setlist:', error);
                toast.error('Failed to update setlist');
                loadSetlist();
            }
        }
    };

    if (isLoading) {
        return (
            <div className="min-h-screen bg-gray-900 flex items-center justify-center">
                <div className="text-white">Loading setlist...</div>
            </div>
        );
    }

    if (!setlist) {
        return (
            <div className="min-h-screen bg-gray-900 flex items-center justify-center">
                <div className="text-red-500">Setlist not found</div>
            </div>
        );
    }

    return (
        <div className="min-h-screen bg-gray-900">
            <div className="border-b border-gray-800">
                <div className="px-4 py-4 max-w-7xl mx-auto">
                    <Link
                        href={`/bands/${activeBand?.id}/setlists`}
                        className="inline-flex items-center text-gray-400 hover:text-white mb-4"
                    >
                        <ArrowLeft className="w-4 h-4 mr-2" />
                        Back to Setlists
                    </Link>

                    <div className="flex items-baseline justify-between">
                        <h1 className="text-2xl font-bold text-white">{setlist.name}</h1>
                        <div className="flex items-center gap-4">
                            <div className="flex items-center gap-2 text-gray-400">
                                <Clock className="w-4 h-4" />
                                <span>{setlist.format.setDuration} mins/set</span>
                            </div>
                            <button
                                onClick={() => setIsAddSongsOpen(true)}
                                className="bg-orange-500 hover:bg-orange-600 text-white px-4 py-2 rounded-lg flex items-center gap-2"
                            >
                                <Plus className="w-4 h-4" />
                                Add Songs
                            </button>
                        </div>
                    </div>
                </div>
            </div>

            <div className="max-w-7xl mx-auto p-4">
                <DndContext
                    onDragStart={handleDragStart}
                    onDragOver={handleDragOver}
                    onDragEnd={handleDragEnd}
                >
                    <div className="space-y-6">
                        {setlist.sets.map((set) => (
                            <SetlistSet
                                key={set.id}
                                set={set}
                                songs={setlist.songDetails || {}}
                                isOver={activeSetId === set.id}
                                onAddClick={() => {
                                    setSelectedSetId(set.id);
                                    setIsAddSongsOpen(true);
                                }}
                            />
                        ))}
                    </div>
                </DndContext>
            </div>

            <AddSongsModal
                isOpen={isAddSongsOpen}
                onClose={() => {
                    setIsAddSongsOpen(false);
                    setSelectedSetId(null);
                }}
                onAddSongs={handleAddSongs}
                playbookSongs={playbookSongs}
                existingSongIds={existingSongIds}
            />
        </div>
    );
}