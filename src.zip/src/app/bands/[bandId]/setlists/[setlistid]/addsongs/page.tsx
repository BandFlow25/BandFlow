import { useEffect, useState } from "react";
import { DndContext, DragEndEvent } from "@dnd-kit/core";
import { useBand } from "@/contexts/BandProvider";
import { getSetlist, updateSetlistSets } from "@/lib/services/firebase/setlists";
import { SetlistSet } from "@/components/Setlists/SetlistSet";
import { PlayBookListHeader } from "@/components/songs/PlayBook/PlayBookListHeader";
import { PlayBookListContent } from "@/components/songs/PlayBook/PlayBookListContent";
import { toast } from "react-hot-toast";
import { Loader2 } from "lucide-react";

export default function AddSongsPage() {
  const { activeBand } = useBand();
  const [setlist, setSetlist] = useState<Setlist | null>(null);
  const [playbookSongs, setPlaybookSongs] = useState<{ id: string; title: string; artist: string }[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState("");
  const [includeExisting, setIncludeExisting] = useState(false);
  const setlistId = "example-setlist-id"; // Replace with actual logic

  useEffect(() => {
    if (activeBand?.id && setlistId) {
      loadSetlist();
      loadPlaybookSongs();
    }
  }, [activeBand?.id, setlistId]);

  const loadSetlist = async () => {
    try {
      if (!activeBand?.id || !setlistId) throw new Error("Missing band or setlist ID");
      const data = await getSetlist(activeBand.id, setlistId);
      setSetlist(data);
    } catch (error) {
      console.error("Error loading setlist:", error);
      toast.error("Failed to load setlist.");
    } finally {
      setIsLoading(false);
    }
  };

  const loadPlaybookSongs = async () => {
    try {
      const mockSongs = [
        { id: "1", title: "Song A", artist: "Artist 1" },
        { id: "2", title: "Song B", artist: "Artist 2" },
      ];
      setPlaybookSongs(mockSongs);
    } catch (error) {
      console.error("Error loading playbook songs:", error);
      toast.error("Failed to load playbook songs.");
    }
  };

  const handleDragEnd = (event: DragEndEvent) => {
    const { active, over } = event;

    if (!setlist || !over || !activeBand?.id) return;

    const targetSet = setlist.sets.find((set) => set.id === over.id);
    if (!targetSet) return;

    const song = playbookSongs.find((song) => song.id === active.id);
    if (!song) return;

    const newSets = setlist.sets.map((set) => {
      if (set.id === targetSet.id) {
        return {
          ...set,
          songs: [
            ...set.songs,
            {
              songId: song.id,
              position: set.songs.length,
            },
          ],
        };
      }
      return set;
    });

    try {
      updateSetlistSets(activeBand.id, setlist.id, newSets);
      setSetlist({ ...setlist, sets: newSets });
    } catch (error) {
      console.error("Error updating setlist:", error);
      toast.error("Failed to update setlist.");
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-gray-500" />
      </div>
    );
  }

  if (!setlist) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p className="text-gray-500">No setlist found.</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col bg-gray-900">
      <div className="p-4 border-b border-gray-800">
        <PlayBookListHeader
          title="Playbook"
          count={playbookSongs.length}
          searchQuery={searchQuery}
          onSearchChange={setSearchQuery}
        />
        <label className="flex items-center gap-2 text-gray-400 mt-2">
          <input
            type="checkbox"
            checked={includeExisting}
            onChange={(e) => setIncludeExisting(e.target.checked)}
            className="rounded border-gray-700 bg-gray-800"
          />
          Include songs already in setlist
        </label>
      </div>

      <div className="flex-1 flex flex-col lg:flex-row overflow-hidden">
        {/* Playbook Section */}
        <div className="flex-1 overflow-y-auto">
          <PlayBookListContent
            songs={playbookSongs.filter((song) =>
              includeExisting || !setlist.sets.some((set) =>
                set.songs.some((s) => s.songId === song.id)
              )
            )}
            isLoading={false}
            error={null}
            selectedSongs={new Set()}
            onSongToggle={() => {}}
            isMultiSelectMode={false}
          />
        </div>

        {/* Setlist Section */}
        <div className="flex-1 bg-gray-800 p-4">
          <DndContext onDragEnd={handleDragEnd}>
            {setlist.sets.map((set) => (
              <SetlistSet
                key={set.id}
                set={set}
                songs={setlist.songDetails || {}}
              />
            ))}
          </DndContext>
        </div>
      </div>
    </div>
  );
}
