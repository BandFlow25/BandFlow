// src/components/setlists/SetlistSet.tsx
import { useDroppable } from '@dnd-kit/core';
import { SortableContext, verticalListSortingStrategy } from '@dnd-kit/sortable';
import { cn } from '@/lib/utils';
import { SetlistSongCard } from './SetlistSongCard';
import type { BandSong } from '@/lib/types/song';
import type { SetlistSet } from '@/lib/types/setlist';
import { DurationtoMinSec } from '@/lib/services/bandflowhelpers/SetListHelpers';
import { Plus } from 'lucide-react';

interface SetlistSetProps {
  set: SetlistSet;
  songs: Record<string, BandSong>;
  isOver?: boolean;
  onAddClick?: () => void;
}

export function SetlistSet({ set, songs, isOver, onAddClick }: SetlistSetProps) {
  const { setNodeRef } = useDroppable({
    id: set.id
  });

  const totalDuration = set.songs.reduce((total, song) => {
    const songDetails = songs[song.songId];
    return total + (songDetails?.metadata?.duration ? parseInt(songDetails.metadata.duration) : 0);
  }, 0);

  const targetDuration = set.targetDuration * 60;
  const durationDiff = Math.abs(totalDuration - targetDuration);
  const durationPercentage = (durationDiff / targetDuration) * 100;

  let durationStatus = 'text-green-500';
  if (durationPercentage > 7.5) {
    durationStatus = totalDuration > targetDuration ? 'text-red-500' : 'text-yellow-500';
  }

  return (
    <div 
      ref={setNodeRef}
      className={cn(
        "bg-gray-800 rounded-lg overflow-hidden",
        isOver && "ring-2 ring-orange-500"
      )}
    >
      <div className="flex items-center justify-between px-4 py-3 bg-gray-700">
        <h2 className="font-semibold text-white">{set.name}</h2>
        <div className="flex items-center gap-4">
          <div className={cn("text-sm", durationStatus)}>
            {DurationtoMinSec(totalDuration)} / {set.targetDuration}m
          </div>
          <button
            onClick={onAddClick}
            className="p-1.5 hover:bg-gray-600 rounded-lg transition-colors"
          >
            <Plus className="w-4 h-4 text-gray-300" />
          </button>
        </div>
      </div>

      <div className="p-4">
        {set.songs.length === 0 ? (
          <button
            onClick={onAddClick}
            className="w-full text-gray-400 text-center py-8 hover:text-gray-300 transition-colors"
          >
            Drop songs here or click to add
          </button>
        ) : (
          <SortableContext 
            items={set.songs.map(s => s.songId)} 
            strategy={verticalListSortingStrategy}
          >
            <div className="space-y-2">
              {set.songs.map((song, index) => {
                const songDetails = songs[song.songId];
                if (!songDetails) return null;
                
                return (
                  <SetlistSongCard
                    key={`${set.id}-${song.songId}-${index}`}
                    id={song.songId}
                    song={songDetails}
                    index={index}
                  />
                );
              })}
            </div>
          </SortableContext>
        )}
      </div>
    </div>
  );
}