// src/components/setlists/SetlistSongCard.tsx
import { useSortable } from '@dnd-kit/sortable';
import { CSS } from '@dnd-kit/utilities';
import { GripVertical } from 'lucide-react';
import type { BandSong } from '@/lib/types/song';
import { DurationtoMinSec } from '@/lib/services/bandflowhelpers/SetListHelpers';

interface SetlistSongCardProps {
  id: string;
  song: BandSong;
  index: number;
}

export function SetlistSongCard({ id, song, index }: SetlistSongCardProps) {
  const {
    attributes,
    listeners,
    setNodeRef,
    transform,
    transition,
    isDragging
  } = useSortable({ id });

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
    opacity: isDragging ? 0.5 : 1
  };

  return (
    <div
      ref={setNodeRef}
      style={style}
      className="flex items-center p-3 bg-gray-700/50 rounded-lg group"
    >
      <div
        {...attributes}
        {...listeners}
        className="p-1 opacity-0 group-hover:opacity-100 cursor-grab"
      >
        <GripVertical className="w-4 h-4 text-gray-400" />
      </div>

      <div className="flex-1 min-w-0 px-2">
        <div className="font-medium text-white truncate">{song.title}</div>
        <div className="text-sm text-gray-400 truncate">{song.artist}</div>
      </div>

      {song.metadata?.duration && (
        <div className="text-sm text-gray-400 flex-shrink-0">
          {DurationtoMinSec(parseInt(song.metadata.duration))}
        </div>
      )}
    </div>
  );
}