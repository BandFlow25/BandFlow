'use client';

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Plus, Trash } from 'lucide-react';
import type { BandSong, SongSection } from '@/lib/types/song';
import { toast } from 'react-hot-toast';

interface SongStructureProps {
    song: BandSong | null;
    isLoading: boolean;
    onUpdate: (updates: Partial<BandSong>) => Promise<boolean>;
}

export function SongStructure({ song, isLoading, onUpdate }: SongStructureProps) {
    const [sections, setSections] = useState<SongSection[]>(song?.songSections ?? []);
    const [isEditing, setIsEditing] = useState(false);

    const addSection = () => {
        setSections([...sections, { type: 'Verse', barCount: 8, notes: '' } as SongSection]);
    };

    const removeSection = (index: number) => {
        const updatedSections = sections.filter((_, i) => i !== index);
        setSections(updatedSections);
    };

    const updateSection = (index: number, updatedSection: Partial<SongSection>) => {
        const updatedSections = sections.map((section, i) =>
            i === index ? { ...section, ...updatedSection } : section
        );
        setSections(updatedSections);
    };

    const saveChanges = async () => {
        try {
            const success = await onUpdate({ songSections: sections });
            if (success) {
                toast.success('Song structure updated successfully!');
                setIsEditing(false);
            }
        } catch (error) {
            console.error('Failed to update song structure:', error);
            toast.error('Failed to save changes.');
        }
    };

    if (isLoading || !song) {
        return <div className="text-white">Loading...</div>;
    }

    return (
        <div className="space-y-6">
            <div className="flex justify-between items-center">
                <h3 className="text-lg font-medium text-white">Song Structure</h3>
                {isEditing ? (
                    <div className="flex gap-2">
                        <Button variant="outline" onClick={() => setIsEditing(false)}>
                            Cancel
                        </Button>
                        <Button onClick={saveChanges} className="bg-orange-500 hover:bg-orange-600">
                            Save Changes
                        </Button>
                    </div>
                ) : (
                    <Button
                        onClick={() => setIsEditing(true)}
                        className="bg-orange-500 hover:bg-orange-600"
                    >
                        Edit Structure
                    </Button>
                )}
            </div>

            <div className="space-y-4">
                {sections.map((section, index) => (
                    <div key={index} className="bg-gray-800 p-4 rounded-lg">
                        <div className="flex items-center gap-4">
                            {isEditing ? (
                                <>
                                    <Input
                                        value={section.type}
                                        onChange={(e) =>
                                            updateSection(index, { type: e.target.value })
                                        }
                                        className="bg-gray-700 border-gray-600"
                                        placeholder="Section Type (e.g., Verse)"
                                    />
                                    <Input
                                        type="number"
                                        value={section.barCount || 0}
                                        onChange={(e) =>
                                            updateSection(index, {
                                                barCount: parseInt(e.target.value, 10),
                                            })
                                        }
                                        className="bg-gray-700 border-gray-600"
                                        placeholder="Bars"
                                    />
                                    <Input
                                        value={section.notes}
                                        onChange={(e) =>
                                            updateSection(index, { notes: e.target.value })
                                        }
                                        className="bg-gray-700 border-gray-600"
                                        placeholder="Notes"
                                    />
                                    <Button
                                        variant="outline"
                                        onClick={() => removeSection(index)}
                                        className="text-red-500 hover:text-red-600"
                                    >
                                        <Trash className="w-4 h-4" />
                                    </Button>
                                </>
                            ) : (
                                <div className="flex flex-col space-y-2">
                                    <span className="text-white font-medium">{section.type}</span>
                                    <span className="text-gray-400">{section.barCount} bars</span>
                                    <span className="text-gray-400">{section.notes}</span>
                                </div>
                            )}
                        </div>
                    </div>
                ))}
                {isEditing && (
                    <Button
                        variant="outline"
                        onClick={addSection}
                        className="w-full bg-gray-700 hover:bg-gray-600"
                    >
                        <Plus className="w-4 h-4 mr-2" />
                        Add Section
                    </Button>
                )}
            </div>
        </div>
    );
}
