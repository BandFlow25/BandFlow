'use client';

import { useState } from 'react';
import { useBand } from '@/contexts/BandProvider';
import { useAuth } from '@/contexts/AuthProvider';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Clock, Activity, Music2 } from 'lucide-react';
import type { BandSong } from '@/lib/types/song';
import { toast } from 'react-hot-toast';
import { serverTimestamp, Timestamp } from 'firebase/firestore';

interface SongFeaturesProps {
    song: BandSong | null;
    isLoading: boolean;
    onUpdate: (updates: Partial<BandSong>) => Promise<boolean>;
}

export function SongFeatures({ song, isLoading, onUpdate }: SongFeaturesProps) {
    const { activeBand } = useBand();
    const { user } = useAuth();
    const [isEditing, setIsEditing] = useState(false);
    const [editForm, setEditForm] = useState({
        localTitle: song?.localTitle || '',
        bpm: song?.metadata?.bpm?.toString() || '',
        key: song?.metadata?.key || '',
        duration: song?.metadata?.duration || '',
        personalNote: song?.songNotes?.[user?.uid || '']?.personal || '',
        bandNote: song?.songNotes?.[user?.uid || '']?.band || ''
    });

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!activeBand?.id || !song || !user?.uid) return;

        try {
            const updates: Partial<BandSong> = {
                localTitle: editForm.localTitle !== '' ? editForm.localTitle : undefined, // Allow undefined for optional localTitle
                metadata: {
                    bpm: editForm.bpm !== '' ? parseInt(editForm.bpm) : song.metadata?.bpm ?? 0,
                    key: editForm.key !== '' ? editForm.key : song.metadata?.key ?? '',
                    duration: editForm.duration !== '' ? editForm.duration : song.metadata?.duration ?? '',
                },
                songNotes: song.songNotes
                    ? {
                          ...song.songNotes,
                          [user.uid]: {
                              personal: editForm.personalNote,
                              band: editForm.bandNote,
                              lastUpdated: serverTimestamp() as unknown as Timestamp,
                          },
                      }
                    : {
                          [user.uid]: {
                              personal: editForm.personalNote,
                              band: editForm.bandNote,
                              lastUpdated: serverTimestamp() as unknown as Timestamp,
                          },
                      },
            };
            

            await onUpdate(updates);
            toast.success('Song details updated');
            setIsEditing(false);
        } catch (error) {
            console.error('Error updating song:', error);
            toast.error('Failed to update song details');
        }
    };

    if (isLoading || !song) {
        return <div className="text-white">Loading...</div>;
    }

    return (
        <div className="space-y-6">
            <form onSubmit={handleSubmit} className="space-y-6">
                {/* Title Section */}
                <div className="bg-gray-800 p-4 rounded-lg space-y-4">
                    <h3 className="text-sm font-medium text-gray-300">Title</h3>
                    {isEditing ? (
                        <Input
                            value={editForm.localTitle}
                            onChange={(e) => setEditForm(prev => ({ ...prev, localTitle: e.target.value }))}
                            className="bg-gray-700 border-gray-600"
                            placeholder={song?.title}
                        />
                    ) : (
                        <div className="text-lg font-medium text-white">
                            {song?.localTitle || song?.title}
                        </div>
                    )}
                </div>

                {/* Metadata Section */}
                <div className="bg-gray-800 p-4 rounded-lg space-y-4">
                    <h3 className="text-sm font-medium text-gray-300">Song Features</h3>
                    <div className="space-y-4">
                        {isEditing ? (
                            <>
                                <div>
                                    <label className="text-sm text-gray-400">BPM</label>
                                    <Input
                                        value={editForm.bpm}
                                        onChange={(e) => setEditForm(prev => ({ ...prev, bpm: e.target.value }))}
                                        className="bg-gray-700 border-gray-600"
                                        placeholder={song?.metadata?.bpm?.toString()}
                                    />
                                </div>
                                <div>
                                    <label className="text-sm text-gray-400">Key</label>
                                    <Input
                                        value={editForm.key}
                                        onChange={(e) => setEditForm(prev => ({ ...prev, key: e.target.value }))}
                                        className="bg-gray-700 border-gray-600"
                                        placeholder={song?.metadata?.key}
                                    />
                                </div>
                                <div>
                                    <label className="text-sm text-gray-400">Duration (seconds)</label>
                                    <Input
                                        value={editForm.duration}
                                        onChange={(e) => setEditForm(prev => ({ ...prev, duration: e.target.value }))}
                                        className="bg-gray-700 border-gray-600"
                                        placeholder={song?.metadata?.duration}
                                    />
                                </div>
                            </>
                        ) : (
                            <div className="space-y-2">
                                <div className="flex items-center justify-between">
                                    <span className="text-gray-400 flex items-center gap-2">
                                        <Activity className="w-4 h-4" />
                                        BPM
                                    </span>
                                    <span>{song?.metadata?.bpm || '-'}</span>
                                </div>
                                <div className="flex items-center justify-between">
                                    <span className="text-gray-400 flex items-center gap-2">
                                        <Music2 className="w-4 h-4" />
                                        Key
                                    </span>
                                    <span>{song?.metadata?.key || '-'}</span>
                                </div>
                                <div className="flex items-center justify-between">
                                    <span className="text-gray-400 flex items-center gap-2">
                                        <Clock className="w-4 h-4" />
                                        Duration
                                    </span>
                                    <span>{song?.metadata?.duration || '-'}</span>
                                </div>
                            </div>
                        )}
                    </div>
                </div>

                {/* Action Buttons */}
                <div className="flex justify-end gap-2">
                    {isEditing ? (
                        <>
                            <Button
                                type="button"
                                variant="outline"
                                onClick={() => setIsEditing(false)}
                                className="bg-gray-800 hover:bg-gray-700"
                            >
                                Cancel
                            </Button>
                            <Button
                                type="submit"
                                className="bg-orange-500 hover:bg-orange-600"
                            >
                                Save Changes
                            </Button>
                        </>
                    ) : (
                        <Button
                            type="button"
                            onClick={() => {
                                setEditForm({
                                    localTitle: song?.localTitle || song?.title || '',
                                    bpm: song?.metadata?.bpm?.toString() || '',
                                    key: song?.metadata?.key || '',
                                    duration: song?.metadata?.duration || '',
                                    personalNote: song?.songNotes?.[user?.uid || '']?.personal || '',
                                    bandNote: song?.songNotes?.[user?.uid || '']?.band || ''
                                });
                                setIsEditing(true);
                            }}
                            className="bg-orange-500 hover:bg-orange-600"
                        >
                            Edit Details
                        </Button>
                    )}
                </div>
            </form>
        </div>
    );
}
